create database Banco;

show databases;

use Banco;

create table pessoa(
	id int primary key auto_increment, 
	nome varchar (90) not null,
    cpf  varchar (11) unique not null,
    telefone varchar(14) not null,
    endereco varchar (50) not null
);





create table conta(
	numero_conta int primary key auto_increment, 
	titular varchar (50) not null,
    senha varchar (6) not null,
    pix varchar (11) not null,
    saldo text not null


);