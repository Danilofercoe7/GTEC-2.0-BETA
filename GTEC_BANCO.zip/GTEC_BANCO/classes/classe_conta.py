class banco_conta:
    def __init__(self, numero, titular, senha, cpf, endereco, telefone, saldo=0):
        self.__numero = numero
        self.__titular = titular
        self.__senha = str(senha)
        self.__cpf = cpf
        self.__pix = cpf
        self.__endereco = endereco
        self.__telefone = telefone
        self.__saldo = saldo

    @property
    def numero(self):
        return self.__numero

    @property
    def titular(self):
        return self.__titular

    @property
    def senha(self):
        return self.__senha

    @property
    def cpf(self):
        return self.__cpf

    @property
    def pix(self):
        return self.__pix

    @property
    def endereco(self):
        return self.__endereco

    @property
    def telefone(self):
        return self.__telefone

    @property
    def saldo(self):
        return self.__saldo

    def depositar(self, valor):
        if valor > 0:
            self.__saldo += valor
            print(f"Depósito de R${valor:,.2f} realizado com sucesso!")
        else:
            print("Valor de depósito inválido.")

    def sacar(self, valor):
        if 0 < valor <= self.__saldo:
            self.__saldo -= valor
            print(f"Saque de R${valor:,.2f} realizado com sucesso!")
        else:
            print("Valor de saque inválido ou saldo insuficiente.")

    def transferir(self, destino, valor):
        if 0 < valor <= self.__saldo:
            self.__saldo -= valor
            destino.depositar(valor)
            print(f"Transferência de R${valor:,.2f} para {destino.titular} realizada com sucesso!")
        else:
            print("Valor de transferência inválido ou saldo insuficiente.")

# hitorico de transferir