class Banco:
    def __init__(self, numero, titular, senha, cpf, endereco, telefone):
        self.numero = numero
        self.titular = titular
        self.senha = senha
        self.cpf = cpf
        self.pix = cpf
        self.endereco = endereco
        self.telefone = telefone
        self.saldo = 0.0

    def depositar(self, valor):
        if valor > 0:
            self.saldo += valor
            print(f"Depósito de R${valor:.2f} realizado com sucesso.")
        else:
            print("Valor inválido para depósito.")

    def sacar(self, valor):
        if valor > 0 and self.saldo >= valor:
            self.saldo -= valor
            print(f"Saque de R${valor:.2f} realizado com sucesso.")
        else:
            print("Saldo insuficiente ou valor inválido.")

    def transferir(self, destino, valor):
        if valor > 0 and self.saldo >= valor:
            self.saldo -= valor
            destino.saldo += valor
            print(f"Transferência de R${valor:.2f} para {destino.titular} realizada com sucesso.")
        else:
            print("Transferência não realizada. Verifique o saldo ou o valor.")