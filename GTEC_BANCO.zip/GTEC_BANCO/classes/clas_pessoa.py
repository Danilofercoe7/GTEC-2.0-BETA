class Pessoa:
    def __init__(self, nome, cpf, telefone, endereco, cidade="Não informado", estado="Não informado"):
        self.nome = nome
        self.cpf = cpf
        self.telefone = telefone
        self.endereco = endereco
        self.cidade = cidade
        self.estado = estado

    def _str_(self):
        return f"{self.nome} ({self.cpf}) - {self.telefone} | {self.endereco}, {self.cidade}/{self.estado}"